//para dividir el codigo y que no haya muchas rutas en el otro?

const {Router} = require('express');//significa requiero desde express el metodo router. Permite definir nuevas rutas para mi servidor
const router = Router(); //ejecutar router

router.get('/test', (req,res) => { // cuando visita la ruta, hace/muestra lo que esta dentro de {}
    //res.send('Hello World!');//muestra un string
    //res.json({"Title": "Hello World"});//envia un objeto json 
    const data = {
        "name": "sofia",
        "apellido": "rozenberg"
    };

    res.json(data);
    
})

module.exports = router;