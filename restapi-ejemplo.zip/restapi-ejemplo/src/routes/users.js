const {Router} = require ('express');
const router = Router ();

/*const fetch = require('node-fetch');

router.get('/', async (req, res) => {
    const response = await fetch ('https://jsonplaceholder.typicode.com/users'); //le hace una peticion a ese sitio web
    const users = await response.json(); //la respuesta que trae del sitio web la convierte en json
    res.json(users); //muestra los users sacados de la otra pagina
});

module.exports = router;*/