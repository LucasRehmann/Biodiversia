const {Router} = require('express');
const router = Router();
const underscore = require('underscore');

const movies = require('../sample(simula db).json'); //constante con la info que tiene el archivo sample
console.log (movies);

router.get('/movies', (req, res) => {
    res.json(movies);
});

router.post ('/movies', (req, res) => {
    //console.log (req.body);//devuelve lo que te mando el usuario
    const { title, director, year, rating } = req.body; //guarda lo q mando el usuario en una variable/constante?
    
    if (title && director && year && rating){
        const id = movies.length + 1;
        const newMovie = {...req.body, id}; //crea una nueva pelicula con los datos enviados x el usuario y le agrega el id
        movies.push(newMovie);
        res.json (movies); //reenvia las peliculas pero actualizadas
        //res.status (200); //muestra el status de la pag, por si salio un error o algo asi
    }

    else {
        res.send ('Wrong request');
    }
    res.send('received');
});

router.put('/movies/:id', (req, res) => {
    const{ id} = req.params;
    const { title, director, year, rating } = req.body;

    if (title && director && year && rating){
        underscore.each(movies, (movie, i) => {
        if (movie.id == id){
            movie.title = title;
            movie.director = director;
            movie.year = year;
            movie.rating = rating;
        }
        });

        res.json(movies);
    }

    else {
        res.status (500).json({ error: 'There was an error'});
    }
});

router.delete('/movies/:id', (req, res) => {
    const { id } = req.params; //guarda el parametro, en este caso el id
    underscore.each (movies, (movie, id) =>{ //itera a traves de una lista?
        if (movie.id == id){
            movies.splice (i,1); //elimina la pelicula
        }
    });

res.json(movies);
    
});

module.exports = router;