//npm i *nombre de licencia* => te la descarga?
//npm run dev => ejecuta el comando dev, el comando dev ejecuta nodemon, el cual ejecuta el proyecto? cada vez que guardas cambios


const express = require ( 'express');
const app = express();
const morgan = require('morgan');

//settings
app.set('port', process.env.PORT || 3000); //si ya hay un puerto definido en el sistema o por el servicio de la nube que use es port y si no, que use el 3000
app.set ('json spaces', 2);

//middlewares
app.use(morgan('dev'));
app.use(express.urlencoded({extended: false}));
app.use(express.json());

//routes
app.use(require('./routes/index')); //importa las rutas dentro del otro archivo index
app.use(require('./routes/movies'));
app.use(require('./routes/users'));
//starting the server
app.listen(app.get('port'), () => {
    console.log(`Server on port ${app.get('port')}`);
})